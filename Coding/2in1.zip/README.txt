MeshCentral Dual-Agent Installer — README
==========================================

WHAT THIS DOES
---------------
Installs TWO MeshCentral agents on the same computer, as two separate
background services:

  meshagent64-personal.exe  -> connects to YOUR personal MeshCentral server
  meshagent64-work.exe      -> connects to the WORK MeshCentral server

You unzip everything into one folder and run install_both_agents.bat.
It asks for the admin password ONCE (it elevates itself), then installs
both agents as Windows services, which start automatically at boot with
no further prompts.

BEFORE YOU DEPLOY TO ANY REAL MACHINE
---------------------------------------
Test this on ONE throwaway or low-stakes machine first and reboot it.
Two things can go wrong that I cannot fully verify from here:

1. SERVICE NAME / INSTALL PATH COLLISION (the big one)
   By default, the MeshCentral agent installs itself as a service named
   "Mesh Agent" in "Program Files\Mesh Agent", UNLESS whoever configured
   each server gave their agent custom branding (a different company
   name / service name in the server's agent settings). If both your
   personal agent and the work agent use the DEFAULT branding, installing
   the second one can overwrite or break the first service instead of
   running alongside it.

   The script copies each exe to its own folder (C:\MeshAgent-Personal
   and C:\MeshAgent-Work) before installing, which helps, but the
   Windows SERVICE itself may still collide if both use the default name.

   HOW TO CHECK: after running the script, look at the "Checking
   installed services" output it prints, or open services.msc and
   search for "mesh". You want to see TWO distinct mesh-related
   services running, not one. Also check both device dashboards
   (your server and the work server) to confirm the device shows up
   as ONLINE in both at the same time.

   IF THEY COLLIDED: you'll likely see only one agent connected. You
   may need to ask whoever admins either server to set a custom
   "Company Name" / agent branding for that device group so the two
   agents install under different service names. This is a server-side
   setting, not something this script can fix.

2. WINDOWS DEFENDER / SMARTSCREEN
   A .bat file that self-elevates and installs background services can
   get flagged as suspicious behavior, and an unsigned/downloaded .exe
   can trigger a SmartScreen warning. If this happens:
   - Right-click the zip -> Properties -> tick "Unblock" before
     extracting, to remove the "downloaded from the internet" flag.
   - If a work IT policy manages Defender centrally, a false-positive
     flag may need to be whitelisted by IT, not by you locally.
   - Check Windows Security > Protection history if something gets
     quarantined, rather than assuming the install silently worked.

3. FILENAME CASE SENSITIVITY
   The two original files you had were named meshagent64-JJ.exe and
   meshagent64-jj.exe. Windows treats filenames as case-INSENSITIVE,
   so those two names would have collided and overwritten each other
   on extraction. They have already been renamed in this package to
   meshagent64-personal.exe and meshagent64-work.exe to avoid that —
   do not rename them back to anything differing only by case.

4. UNINSTALLING / ROLLING BACK
   If something needs to be undone on a machine:
   - Run each agent's exe again with: agentexe.exe -uninstall
     (run once per agent, from an elevated prompt)
   - Or remove the service manually via services.msc / sc delete,
     then delete the C:\MeshAgent-Personal and C:\MeshAgent-Work
     folders.
   - Confirm the device disappears from both dashboards afterward.

5. AUTHORIZATION
   You noted this has been signed off by your employer — keep that
   confirmation on record. If you ever expand this beyond the
   originally agreed machines, re-confirm scope with whoever approved
   it rather than assuming blanket permission.

FILES IN THIS PACKAGE
-----------------------
install_both_agents.bat   - run this (as the user, it self-elevates)
meshagent64-personal.exe  - your personal server's agent
meshagent64-work.exe      - the work server's agent
README.txt                - this file
