@echo off
setlocal

:: ======================= SETTINGS =======================
:: Both exe files must sit in the SAME folder as this .bat
set "PERSONAL_EXE=meshagent64-personal.exe"
set "WORK_EXE=meshagent64-work.exe"

:: Each agent gets installed to its own folder so they can't collide
set "PERSONAL_DIR=C:\MeshAgent-Personal"
set "WORK_DIR=C:\MeshAgent-Work"
:: ==========================================================

:: Self-elevate: this is the ONLY admin prompt you'll see
net session >nul 2>&1
if %errorlevel% neq 0 (
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

set "HERE=%~dp0"

if not exist "%HERE%%PERSONAL_EXE%" (
    echo ERROR: Can't find %PERSONAL_EXE% next to this script.
    pause
    exit /b 1
)
if not exist "%HERE%%WORK_EXE%" (
    echo ERROR: Can't find %WORK_EXE% next to this script.
    pause
    exit /b 1
)

echo ============================================
echo Installing PERSONAL agent...
echo ============================================
if not exist "%PERSONAL_DIR%" mkdir "%PERSONAL_DIR%"
copy /Y "%HERE%%PERSONAL_EXE%" "%PERSONAL_DIR%\%PERSONAL_EXE%" >nul
"%PERSONAL_DIR%\%PERSONAL_EXE%" -fullinstall
if %errorlevel% neq 0 (
    echo WARNING: Personal agent install returned an error code: %errorlevel%
)

echo.
echo ============================================
echo Installing WORK agent...
echo ============================================
if not exist "%WORK_DIR%" mkdir "%WORK_DIR%"
copy /Y "%HERE%%WORK_EXE%" "%WORK_DIR%\%WORK_EXE%" >nul
"%WORK_DIR%\%WORK_EXE%" -fullinstall
if %errorlevel% neq 0 (
    echo WARNING: Work agent install returned an error code: %errorlevel%
)

echo.
echo ============================================
echo Checking installed services...
echo ============================================
sc query type= service state= all | findstr /I "mesh"

echo.
echo ============================================
echo Done. READ THE OUTPUT ABOVE.
echo.
echo If you see only ONE "Mesh Agent" style service listed instead of two,
echo the second install likely overwrote the first. See README.txt for
echo how to check and fix this before trusting the deployment.
echo ============================================
pause
